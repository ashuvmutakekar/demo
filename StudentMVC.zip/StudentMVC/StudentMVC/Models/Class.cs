﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using static System.Net.Mime.MediaTypeNames;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace StudentMVC.Models
{
    public class Student
    {
        public int Roll {  get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public static List<Student> GetAllStudents() { 
          List<Student> students = new List<Student>();
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString =@" Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = student_db; Integrated Security = True"; 
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Select * from Students";
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Student s = new Student();
                    s.Roll = dr.GetInt32("Roll");
                    s.Name = dr.GetString("Name");
                    s.Description = dr.GetString("Description");
                    students.Add(s);
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally {

                cn.Close();
            }
            return students;

        }

        public static Student GetSingleStudent(int Roll)
        {
            Student s = null;
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @" Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = student_db; Integrated Security = True";
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Select * from Students where Roll=@Roll";
                cmd.Parameters.AddWithValue("@Roll", Roll);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                   s = new Student();
                    s.Roll = dr.GetInt32("Roll");
                    s.Name = dr.GetString("Name");
                    s.Description = dr.GetString("Description");

                }
                dr.Close();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {

                cn.Close();
            }
            return s;

        }
        public static void UpdateStudent(Student student)
        {
 
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @" Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = student_db; Integrated Security = True";
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Update Students set Name=@Name,Description=@Description where Roll=@Roll";
             
                cmd.Parameters.AddWithValue("@Name", student.Name);
                cmd.Parameters.AddWithValue("@Description", student.Description);
                cmd.Parameters.AddWithValue("@Roll", student.Roll);

                cmd.ExecuteNonQuery();
                
               
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {

                cn.Close();
            }
        }
        public static void DeleteStudent(int Roll)
        {
           
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @" Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = student_db; Integrated Security = True";
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete from Students where Roll=@Roll";
                cmd.Parameters.AddWithValue("@Roll", Roll);
                cmd.ExecuteNonQuery();
              
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {

                cn.Close();
            }
          

        }




        public static void Insert(Student s) {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @" Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = student_db; Integrated Security = True";
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into Students values(@Roll,@Name,@Description)";
                cmd.Parameters.AddWithValue("@Roll", s.Roll);
                cmd.Parameters.AddWithValue("@Name", s.Name);
                cmd.Parameters.AddWithValue("@Description", s.Description);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex) {
                throw;
                    }
            finally { cn.Close(); }

        }

    }
}
