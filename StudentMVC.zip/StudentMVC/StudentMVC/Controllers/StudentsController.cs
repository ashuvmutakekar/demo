﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentMVC.Models;

namespace StudentMVC.Controllers
{
    public class StudentsController : Controller
    {
        // GET: StudentsController
        public ActionResult Index()
        {
            List<Student> students = Student.GetAllStudents();

            return View(students);
        }

        // GET: StudentsController/Details/5
        public ActionResult Details(int id)
        {
           Student s= Student.GetSingleStudent(id);
            return View(s);
        }
        

        // GET: StudentsController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: StudentsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection,Student obj)
        {
            try
            {
                Student.Insert(obj);
                ViewBag.Message = "Sucessfully Inserted";
                return RedirectToAction("Index");
            }
            catch(Exception ex)  
            {
                ViewBag.Message = ex.Message;
                return View();
            }
        }

        // GET: StudentsController/Edit/5
        public ActionResult Edit(int id)
        {
            Student s=Student.GetSingleStudent(id);
            return View(s);
        }

        // POST: StudentsController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id,Student obj)
        {
            try
            {
                Student.UpdateStudent(obj);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: StudentsController/Delete/5
        public ActionResult Delete(int id)
        {
            Student s = Student.GetSingleStudent(id);
            return View(s);
        }

        // POST: StudentsController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                Student.DeleteStudent(id);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
