package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages= {"com.telecom.ticketing.controller","com.telecom.ticketing.service"})
@EntityScan(basePackages= {"com.telecom.ticketing.model"})
@EnableJpaRepositories(basePackages= {"com.telecom.ticketing.repository"})
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

}
