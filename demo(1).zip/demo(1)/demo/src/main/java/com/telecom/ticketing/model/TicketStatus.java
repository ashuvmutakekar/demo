package com.telecom.ticketing.model;

public enum TicketStatus {
    OPEN,
    IN_PROGRESS,
    RESOLVED
}