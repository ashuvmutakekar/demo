package com.telecom.ticketing.service;

import com.telecom.ticketing.model.Ticket;
import com.telecom.ticketing.model.TicketStatus;
import com.telecom.ticketing.repository.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class TicketService {

    @Autowired
    private TicketRepository ticketRepository;

    public Ticket createTicket(Ticket ticket) {
        ticket.setCreateDateTime(LocalDateTime.now());
        ticket.setStatus(TicketStatus.OPEN);
        return ticketRepository.save(ticket);
    }

    public Ticket updateTicket(Long id, Ticket ticketDetails) throws Exception {
        Optional<Ticket> existingTicket = ticketRepository.findById(id);
        if (existingTicket.isEmpty()) {
            throw new Exception("Ticket not found");
        }

        Ticket ticket = existingTicket.get();
        // Only update the status, resolution details, and resolution date time
        ticket.setStatus(ticketDetails.getStatus());
        ticket.setResolutionDetails(ticketDetails.getResolutionDetails());
        if (ticketDetails.getStatus() == TicketStatus.RESOLVED) {
            ticket.setResolutionDateTime(LocalDateTime.now());
        }
        return ticketRepository.save(ticket);
    }

    public List<Ticket> getAllOpenTickets() {
        return ticketRepository.findByStatus(TicketStatus.OPEN);
    }

    public Ticket getTicketById(Long id) throws Exception {
        Optional<Ticket> ticket = ticketRepository.findById(id);
        if (ticket.isEmpty()) {
            throw new Exception("Ticket not found");
        }
        return ticket.get();
    }
}
