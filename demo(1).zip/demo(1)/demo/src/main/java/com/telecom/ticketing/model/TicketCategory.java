package com.telecom.ticketing.model;

public enum TicketCategory {
    SIM,
    CALLING,
    BROADBAND
}