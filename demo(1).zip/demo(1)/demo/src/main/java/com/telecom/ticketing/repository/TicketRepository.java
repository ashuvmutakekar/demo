package com.telecom.ticketing.repository;

import com.telecom.ticketing.model.Ticket;
import com.telecom.ticketing.model.TicketStatus;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TicketRepository extends JpaRepository<Ticket, Long> {

    List<Ticket> findByStatus(TicketStatus status);

    Optional<Ticket> findById(Long id);
}