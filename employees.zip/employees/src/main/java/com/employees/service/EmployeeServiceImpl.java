package com.employees.service;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employees.entity.Employee;
import com.employees.entity.EmployeeDTO;
import com.employees.repository.EmployeeRepository;
@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepository employeeRepository;
	

    @Override
    public Employee addNewEmployee(EmployeeDTO emp) {
        Employee employee = new Employee();
        
        BeanUtils.copyProperties(emp, employee);
        
        employee.setJoining_date(LocalDate.now());
        
        return employeeRepository.save(employee);
    }


	@Override
	public EmployeeDTO getById(int id) {
		Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found with ID " + id));
	EmployeeDTO dto = new EmployeeDTO();
		BeanUtils.copyProperties(employee, dto);
	return dto;
	}


	@Override
	public Employee updateEmployee(int id, EmployeeDTO empDTO) {
	    Employee employee = employeeRepository.findById(id)
	            .orElseThrow(() -> new RuntimeException("Employee not found with ID " + id));
	    
	    if (empDTO.getName() != null) {
	        employee.setName(empDTO.getName());
	    }
	    if (empDTO.getDepartment() != null) {
	        employee.setDepartment(empDTO.getDepartment());
	    }
	    if (empDTO.getDesignation() != null) {
	        employee.setDesignation(empDTO.getDesignation());
	    }
	    Double sal = empDTO.getSalary();
	    if (sal!=null) {
	        employee.setSalary(empDTO.getSalary());
	    } 

	    return employeeRepository.save(employee);
	}


	@Override
	public void deleteEmployee(int id) {
		
	        employeeRepository.deleteById(id);		
	}

}
