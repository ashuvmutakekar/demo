package com.employees.service;

import java.util.Optional;

import com.employees.entity.Employee;
import com.employees.entity.EmployeeDTO;

public interface EmployeeService {

	Employee addNewEmployee(EmployeeDTO emp);
	EmployeeDTO getById(int id);
	Employee updateEmployee(int id , EmployeeDTO dto);
	void deleteEmployee(int id);
	
}
