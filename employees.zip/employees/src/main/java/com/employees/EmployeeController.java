package com.employees;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.employees.entity.Employee;
import com.employees.entity.EmployeeDTO;
import com.employees.service.EmployeeService;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;
	
	@PostMapping
	public Employee createNewEmp(@RequestBody EmployeeDTO dto) {
		return employeeService.addNewEmployee(dto);
	}
	@PutMapping("/{id}")
    public Employee updateEmployee(@PathVariable int id, @RequestBody EmployeeDTO empDTO) {
        return employeeService.updateEmployee(id, empDTO);
    }
	 @GetMapping("/{id}")
	    public EmployeeDTO getEmployeeById(@PathVariable int id) {
	        return employeeService.getById(id);
	    }
	 @DeleteMapping("/{id}")
	 public String deleteEmployee(@PathVariable int id) {
	        employeeService.deleteEmployee(id);
	        return "Employee with ID " + id + " has been deleted successfully.";
	    }
	 
}
